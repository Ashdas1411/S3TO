S3TO Raspberry Pi 1 Client

Client ID: pi1
Model: SimpleMLP
Dataset: client_data.npz
Device: CPU

Connectivity test:
python3 physical_fl_client.py --mode smoke --host LAPTOP_IP --port 19201 --client-id pi1

Training and update:
python3 physical_fl_client.py --mode train --host LAPTOP_IP --port 19201 --client-id pi1 --round 1 --data client_data.npz --initial-model initial_model_mlp.pt --device cpu

Replace LAPTOP_IP with the laptop's reachable IP address.
